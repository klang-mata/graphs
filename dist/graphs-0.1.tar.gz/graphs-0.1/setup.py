from setuptools import setup, find_packages

setup(
    name="graphs",
    version="0.1",
    packages=find_packages(),
    description="A library for graph operations",
    author="Matej Klang",
    author_email="klangm@vscht.cz",
    url="https://github.com/klang-mata/graphs",
)